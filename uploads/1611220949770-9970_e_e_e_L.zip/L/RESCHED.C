/* resched.c - resched */

#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <q.h>
#include "myHeader.h"

/*------------------------------------------------------------------------
 *  resched  --  reschedule processor to highest priority ready process
 *
 * Notes:	Upon entry, currpid gives current process id.
 *		Proctab[currpid].pstate gives correct NEXT state for
 *			current process if other than PRCURR.
 *------------------------------------------------------------------------
 */
int	resched()
{
	register struct	pentry	*optr;	/* pointer to old process entry */
	register struct	pentry	*nptr;	/* pointer to new process entry */
	int k;
	optr = &proctab[currpid];
	if ( optr->pstate == PRCURR ) 
         {
		/* no switch needed if current prio. higher than next	*/
		/* or if rescheduling is disabled ( pcxflag == 0 )	*/
		if ((sys_pcxget() == 0) || (preempt > 0))	
		{
			return;
		}
		/* force context switch */
		optr->pstate = PRREADY;
		readyFlag = 0;
		insert(currpid,rdyhead,optr->pprio);
		readyFlag = 1;
	} /* if */ 
	else if ( sys_pcxget() == 0 ) 
	{
		kprintf("pid=%d state=%d name=%s",currpid,optr->pstate,optr->pname);
		panic("Reschedule impossible in this state");
	} /* else if */

	if (my_i == my_j)
	{
		my_i++;
		my_j = 0;
	}
	currpid = q[rdytail].qprev;
	for (k = 0; k < my_j; k++)
	{
		struct qent *myptr = &q[currpid];
		myptr = myptr->qprev;
		if ((myptr != rdyhead))
		{
			currpid = myptr;
		}
		else 
		{
			my_i = 1;
			my_j = -1;
			currpid = q[rdytail].qprev;
		}
	}
	my_j++;
	dequeueFlag = 0;
	nptr = &proctab[ dequeue(currpid) ];
	dequeueFlag = 1;
	nptr->pstate = PRCURR;		/* mark it currently running	*/
	preempt = QUANTUM;		/* reset preemption counter	*/
	ctxsw(&optr->pregs,&nptr->pregs);

	/* The OLD process returns here when resumed. */

	return;
}
