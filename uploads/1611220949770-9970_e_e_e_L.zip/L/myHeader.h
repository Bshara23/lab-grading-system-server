// balls.h

extern int my_i;
extern int my_j;
extern int dequeueFlag;
extern int readyFlag;