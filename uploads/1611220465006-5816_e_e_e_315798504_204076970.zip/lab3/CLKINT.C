/* clkint.c - clkint */

#include <conf.h>
#include <kernel.h>
#include <sleep.h>
#include <io.h>
#include "original.h"

/*------------------------------------------------------------------------
 *  clkint  --  clock service routine
 *  called at every clock tick and when starting the deferred clock
 *------------------------------------------------------------------------
 */
/* --------------- CHANGE --------------- */
int  convert_to_binary(int x);
int readclk();
/* --------------- END CHANGE --------------- */


INTPROC clkint(mdevno)
int mdevno;				/* minor device number		*/
{
	int	i;
    int resched_flag;
    /* --------------- CHANGE --------------- */
    int clockFlag=readclk();
    //switching between flags according to the time if clockFlag=0 it means we are not in 18:00-20:00
    //that flag will be use in RESCHED.c file to tell which schedule to perform according to the time
        if(clockFlag==0)
        {myReschedFlag=0;}
        else{myReschedFlag=1;}
/* --------------- END CHANGE --------------- */
	   tod++;

        resched_flag = 0;
	if (slnempty)
		if ( (--*sltop) <= 0 )
                     {
                        resched_flag = 1;
			wakeup();
                     } /* if */
	if ( (--preempt) <= 0 )
             resched_flag = 1;

       if (resched_flag == 1)
 		resched();
    }
 

/* --------------- CHANGE --------------- */
int  convert_to_binary(int x)
{
 int i;
 int temp, scale, result;
 

  temp =0;
  scale = 1;
  for(i=0; i < 4; i++)
   {
     temp = temp + (x % 2)*scale;
     scale *= 2;
     x = x >> 1;
   } // for

  result = temp;
  temp = 0;

  scale = 1;
  for(i=0; i < 4; i++)
   {
     temp = temp + (x % 2)*scale;
     scale *= 2;
     x = x >> 1;
   } // for

  temp *= 10;
  result = temp + result;
  return result;

} // convert_to_binary


//to read the current time
int readclk()
{
  int i;
  int hour, min, sec;
  hour = min = sec = 0;

  asm {
   PUSH AX
   MOV AL,0
   OUT 70h,AL
   IN AL,71h
   MOV BYTE PTR sec,AL

   MOV AL,2
   OUT 70h,AL
   IN AL,71h
   MOV BYTE PTR min,AL

   MOV AL,4
   OUT 70h,AL
   IN AL,71h
   MOV BYTE PTR hour,AL

   POP AX
  } // asm

  sec = convert_to_binary(sec);
  min = convert_to_binary(min);
  hour = convert_to_binary(hour);

     if(hour>=18&&hour<=19)
    {
      if(min>=0&&min<=59)
      {
          if(sec>=0&&sec<=59)
            return 1;

    }

    }
    if(hour==20&&min==0&&sec==0)
    {
          return 1;           

    }
    return 0;
}

/* --------------- END CHANGE --------------- */

