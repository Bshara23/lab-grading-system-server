/* ready.c - ready */

#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <q.h>
#include "original.h"

/*------------------------------------------------------------------------
 *  ready  --  make a process eligible for CPU service
 *------------------------------------------------------------------------
 */
int	ready (pid)
	int	pid;			/* id of process to make ready	*/
{
	register struct	pentry	*pptr;

	pptr = &proctab[pid];
	pptr->pstate = PRREADY;
	// reset on adding a new proc to the queue
	if (rdyFlag == 1)
	{
		xi = 1;
		xj = 0;
	}
	insert(pid,rdyhead,pptr->pprio);
	return(OK);
}
