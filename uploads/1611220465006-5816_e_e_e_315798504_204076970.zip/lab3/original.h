extern int xi;
extern int xj;
extern int qFlag;
extern int rdyFlag;
extern int myReschedFlag;