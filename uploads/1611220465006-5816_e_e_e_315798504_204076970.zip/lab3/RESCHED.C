/* resched.c - resched */

#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <q.h>
#include "original.h"

/*------------------------------------------------------------------------
 *  resched  --  reschedule processor to highest priority ready process
 *
 * Notes:	Upon entry, currpid gives current process id.
 *		Proctab[currpid].pstate gives correct NEXT state for
 *			current process if other than PRCURR.
 *------------------------------------------------------------------------
 */
int	resched()
{
//if our resched flag = 0 it means we do the original xinu schedule 
/* --------------- CHANGE --------------- */
	register struct	pentry	*optr;	/* pointer to old process entry */
	register struct	pentry	*nptr;	/* pointer to new process entry */
	int i;

	if(myReschedFlag==0)
	{
/* --------------- END CHANGE --------------- */
    

	optr = &proctab[currpid];
	if ( optr->pstate == PRCURR ) 
         {
		/* no switch needed if current prio. higher than next	*/
		/* or if rescheduling is disabled ( pcxflag == 0 )	*/
		if ( sys_pcxget() == 0 || lastkey(rdytail) < optr->pprio
                 || ( (lastkey(rdytail) == optr->pprio) && (preempt > 0) ) )
			return;
		/* force context switch */
		optr->pstate = PRREADY;
		insert(currpid,rdyhead,optr->pprio);
	} /* if */ 
        else if ( sys_pcxget() == 0 ) 
            {
		kprintf("pid=%d state=%d name=%s",
			currpid,optr->pstate,optr->pname);
		panic("Reschedule impossible in this state");
	    } /* else if */

	/* remove highest priority process at end of ready list */

	nptr = &proctab[ (currpid = getlast(rdytail)) ];
	nptr->pstate = PRCURR;		/* mark it currently running	*/
	preempt = QUANTUM;		/* reset preemption counter	*/
	ctxsw(&optr->pregs,&nptr->pregs);
	/* The OLD process returns here when resumed. */
	return;

	}

   //if we got to here the time is 18:00-20:00 and it means that we do the new process schedule
/* --------------- CHANGE --------------- */
	else{

 /* --------------- END CHANGE --------------- */
	optr = &proctab[currpid];
	if ( optr->pstate == PRCURR ) 
         {
		/* no switch needed if current prio. higher than next	*/
		/* or if rescheduling is disabled ( pcxflag == 0 )	*/
		if ((sys_pcxget() == 0) || (preempt > 0))	
		{
			return;
		}
		/* force context switch */
		optr->pstate = PRREADY;
 /* --------------- CHANGE --------------- */
		// set rdyflag to 0 to reset on creating a new proc
		rdyFlag = 0;
		insert(currpid,rdyhead,optr->pprio);
		rdyFlag = 1;
 /* --------------- END CHANGE --------------- */
	} /* if */ 
	else if ( sys_pcxget() == 0 ) 
	{
		kprintf("pid=%d state=%d name=%s",currpid,optr->pstate,optr->pname);
		panic("Reschedule impossible in this state");
	} /* else if */

 /* --------------- CHANGE --------------- */
	if (xi == xj)
	{
		xi++;
		xj = 0;
	}
	currpid = q[rdytail].qprev;

	// iterate over the q until proc at index uj is reached
	// ordered by prio since it's q
	for (i = 0; i < xj; i++)
	{
		struct qent *myptr = &q[currpid];
		myptr = myptr->qprev;
		// set the current proc
		if ((myptr != rdyhead))
			currpid = myptr;
		else 
		{
			// if we reached the end then reset
			xi = 1;
			xj = -1;
			currpid = q[rdytail].qprev;
		}
	}
	xj++;
	// set queue to 0 to reset upon dequeuing
	qFlag = 0;
	nptr = &proctab[ dequeue(currpid) ];
	qFlag = 1;
	nptr->pstate = PRCURR;/* mark it currently running	*/
	preempt = nptr->pprio/25;/* reset preemption counter to be priority of the process divide by 25	*/
 /* --------------- END CHANGE --------------- */
	ctxsw(&optr->pregs,&nptr->pregs);
            
	/* The OLD process returns here when resumed. */
	return;
}
}
